# Get Good Games v0.60
# by Astar114 & Special thanks to NouhiDev

# --------Settings-------- #

# Mode: 0 [Find New Games]
# Mode: 1 [Update game data in database (excluding likes/badges)]
# Mode: 2 [Scan Votes for games in database]
# Mode: 3 [Scan Badges for games in database]
MODE = 0

# Requirements for a game to be added to database | Default: 3 & 12
MIN_FAVORITES = 3
MIN_VISITS = 12

# [Filter votes: True] Filters games with less than x likes + dislikes | Default: 2
MIN_POPULARITY = 2 

# [Filter votes: True] Filters games with less than x like/dislike ratio: 0.5
MIN_RATIO = 0.5 

# [For Mode: 2] Filter votes: False [No filtering] | True [Removes games from database if popularity/ratio don't meet requirements]
FILTER_VOTES = False

# --------Requests-------- #

# How many games per request should be requested | Default: 80
BATCH_SIZE = 80

# Delay between requests | Default: 0.1s | [Mode: 2] 0.45s | [Mode: 3] 0.02s
REQUESTS_DELAY = 0.1

# Delay between requests when rate limited | Default: 1s
RATE_LIMIT_DELAY = 1

# Min amount of consecutive requests to not use rate limit delay | Default: 80
RATE_LIMIT_THRESHOLD = 80

# Delay between retries if request fails | Default: 1s
REQUEST_RETRY_DELAY = 1 

# How often the database should update | Default: 20s
UPLOAD_DELAY = 20

# Max allowed requests at once | Default: 200  
MAX_CONCURRENT_REQUESTS = 200

# ----------Misc---------- #

# How often the GUI should refresh | Default: 1s
GUI_REFRESH_DELAY = 1

# Roughly how many games currently exist on Roblox (9/14/2023)
MAX_GAMES = 5091000000  

# ----ANSI Escape Codes---- #

RED = '\033[91m'
DARK_RED = '\033[0;31m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
RESET = '\033[0m'
GRAY = '\033[90m'
BOLD = '\033[1m'
UNDERLINE = '\033[4m'
CYAN = '\033[96m'

# --------Save File-------- #

try:
	from saved_last_ids import *
except:
	new_file = open('saved_last_ids.py', 'w')
	new_file.write(
	'last_find_uid = 1\n'+
	'last_update_db_id = 1\n'+
	'last_votes_db_id = 1\n'+
	'last_badge_db_id = 1'
	)
	new_file.close()
	from saved_last_ids import *

# -----SQLite Database----- #

import sqlite3

con = sqlite3.connect('games.db')
con.execute('PRAGMA journal_mode = WAL')
cur = con.cursor()

con.execute('''
	CREATE TABLE IF NOT EXISTS games (
		uid PRIMARY KEY, 
		place_id, 
		name, 
		ratio, 
		popularity,
		visits,
		players, 
		desc, 
		created,
		updated,
		max_players,
		creator,
		genre,
		badge_count,
		rarest_badge
	)
''')

# ---Imports & Variables--- #

from aiohttp import ClientSession, TCPConnector
from datetime import timedelta

from time import monotonic 
from random import random

from os import system
import asyncio

system('cls')
last_avg_reset_time = monotonic()
last_upload_time = monotonic()
recently_saved = False

filtered_ids = 0
resettable_scanned_uids = 0
latest_finished_batch = 0

active_requests = 0
consecutive_success_requests = 0
failed_requests = 0

current_req_delay = REQUESTS_DELAY
latest_error = f'{GREEN}No errors'

# Different variables for each mode
MODE_INFO = ((last_find_uid, 'last_find_uid', 'Finding games', 'games', 'https://games.roblox.com/v1/games?universeIds='), 
			(last_update_db_id, 'last_update_db_id', 'Updating games', 'games', 'https://games.roblox.com/v1/games?universeIds='),
			(last_votes_db_id, 'last_votes_db_id', 'Scanning votes', 'votes', 'https://games.roblox.com/v1/games/votes?universeIds='),
			(last_badge_db_id, 'last_badge_db_id', 'Scanning badges', 'games'))

local_last_id = MODE_INFO[MODE][0]
local_last_id_name = MODE_INFO[MODE][1]

mode_name = MODE_INFO[MODE][2]
target_name = MODE_INFO[MODE][3]
target_url = MODE_INFO[MODE][4] if MODE != 3 else None

DEFAULT_DESC1 = 'This is your very first Roblox creation. Check it out, then make it your own with Roblox Studio!'
DEFAULT_DESC2 =	'This is your very first ROBLOX creation. Check it out, then make it your own with ROBLOX Studio!'

if MODE != 0:
	cur.execute("SELECT COUNT(uid) from games")	
	MAX_GAMES = cur.fetchall()[0][0]

SCANNABLE_GAMES = MAX_GAMES - local_last_id
BATCH_SIZE = 1 if MODE == 3 else BATCH_SIZE

# ------Startup Errors------ #

try:
	con.execute('BEGIN EXCLUSIVE')
except:
	print(f'{RED}{UNDERLINE}ERROR:{RESET} Database is {RED}locked{RESET} and cannot be modifed.')
	print(f'       Please {YELLOW}commit/revert{RESET} any changes made to the database in your {YELLOW}SQLITE browser or script\n{GRAY}')
	exit()
	
if local_last_id < 0:
	print(f"{RED}{UNDERLINE}ERROR:{RESET} {YELLOW}'{local_last_id_name}'{RESET} in {YELLOW}'saved_last_ids.py'{RESET} is negative, please change it to be above 0\n{GRAY}")
	exit()

if MODE == 0 and last_find_uid > MAX_GAMES:
	print(f"{RED}{UNDERLINE}ERROR:{RESET} {YELLOW}'last_find_uid'{RESET} in {YELLOW}'saved_last_ids.py'{RESET} is bigger than allowed, please change it to be below {MAX_GAMES}\n{GRAY}")
	exit()

elif MODE != 0:
	if MAX_GAMES == 0:
	
		print(f"{RED}{UNDERLINE}ERROR:{RESET} No games found in database, please edit {YELLOW}'get_game_data.py'{RESET}") 
		print(f"       and set {YELLOW}'MODE'{RESET} to 0 and run it until there are games\n{GRAY}")
		exit()
	
	elif local_last_id > MAX_GAMES:
		print(f"{RED}{UNDERLINE}ERROR:{RESET} Database entry {local_last_id} doesn't exist, please change {YELLOW}'{local_last_id_name}'{RESET} in {YELLOW}'saved_last_ids.py'{RESET} to be below {MAX_GAMES}\n{GRAY}")
		exit()

# --------Main Code-------- #
	
	
async def print_stats(START_TIME):
	
	global latest_error, last_avg_reset_time, recently_saved
	
	print(f'  {UNDERLINE}{CYAN}Starting...{RESET}')
	print(f'  {GRAY}- Current Settings -')
	
	if MODE == 0:
		print(f'  * Starting from {RESET}UID {local_last_id}')
	else:
		print(f'  * Starting from db {RESET}ID {local_last_id}')
	print(f'{GRAY}  * Batch Size: {RESET}{BATCH_SIZE} UIDS/req')
	print(f'{GRAY}  * Delay between requests: {RESET}{REQUESTS_DELAY}s')
	
	print(f'\n{GRAY}  * Mode: {YELLOW}{MODE} {GRAY}> {YELLOW}{mode_name}')
	if MODE == 0:
		print(f'{GRAY}  * Min Favs: {RESET}{MIN_FAVORITES}')
		print(f'{GRAY}  * Min Visits: {RESET}{MIN_VISITS}')
		
	elif MODE == 2:
	
		if FILTER_VOTES:
			print(f'{GRAY}  * Filter Votes: {GREEN}ON')
		else:
			print(f'{GRAY}  * Filter Votes: {RED}OFF')
			
		print(f'{GRAY}  * Min Popularity: {RESET}{MIN_POPULARITY}')
		print(f'{GRAY}  * Min Ratio: {RESET}{MIN_RATIO}')
	
	await asyncio.sleep(4)
	
	while True: 
		await asyncio.sleep(GUI_REFRESH_DELAY)
		
		current_time = monotonic()
		total_scanned_uids = min(local_last_id + latest_finished_batch, MAX_GAMES)
		elapsed_time = current_time - START_TIME

		uids_remaining = MAX_GAMES - total_scanned_uids
		total_avg_games_per_s = latest_finished_batch/elapsed_time

		# To avoid zero division error
		result = total_avg_games_per_s and uids_remaining / total_avg_games_per_s or 0
		seconds_remaining = result

		# Same here
		avg_games_per_s = current_time - last_avg_reset_time and resettable_scanned_uids/(current_time - last_avg_reset_time) or 0
		avg_found_per_s = filtered_ids/elapsed_time

		equal_bar_end = f'\n{GRAY}==================================[ {RESET}{timedelta(seconds=round(elapsed_time))}{GRAY} ]======================================='
		equal_bar_start = '=' * (len(equal_bar_end)-15)

		if consecutive_success_requests > RATE_LIMIT_THRESHOLD:
			latest_error = f'{GREEN}No errors'

		system('cls')
		print(f'{GRAY}{equal_bar_start}')
		print(f'  {UNDERLINE}{CYAN}{mode_name}...{RESET}')
		print(f'  {GRAY}*{RESET} {total_scanned_uids}/{MAX_GAMES} ({CYAN}{(total_scanned_uids/MAX_GAMES * 100):.5f}%{RESET}) games scanned {GRAY}| {latest_finished_batch} games scanned this session\n')

		if seconds_remaining > 86400:
			print(f'  {GRAY}*{RESET} Time Remaining: {YELLOW}{seconds_remaining/86400:.3f}{RESET} days {GRAY}| {active_requests}/{MAX_CONCURRENT_REQUESTS} reqs')
		else:
			print(f'  {GRAY}*{RESET} Time Remaining: {YELLOW}{seconds_remaining/3600:.3f}{RESET} hours {GRAY}| {active_requests}/{MAX_CONCURRENT_REQUESTS} reqs')
			
		print(f'  {GRAY}*{RESET} Avg Scan Speed: {UNDERLINE}{YELLOW}{avg_games_per_s:.3f}{RESET} games/s {GRAY}> {avg_games_per_s*86400:.0f} games/day')

		if MODE == 0 or (MODE == 2 and FILTER_VOTES): 
			print(f'  {GRAY}*{RESET} Avg Find Speed: {avg_found_per_s:.3f}{RESET} games/s {GRAY}> {avg_found_per_s*86400:.0f} games/day{RESET}\n')
		elif MODE == 3:
			print(f'  {GRAY}*{RESET} Badge Find Speed: {avg_found_per_s:.3f}{RESET} badges/s {GRAY}> {avg_found_per_s*86400:.0f} badges/day{RESET}\n')

		if failed_requests == 0:
			print(f'  {GRAY}*{RESET} Failed Requests: {GREEN}0{RESET} this session {GRAY}| Req delay: {current_req_delay}s | Batch size: {BATCH_SIZE}')
		else:
			print(f'  {GRAY}*{RESET} Failed Requests: {UNDERLINE}{RED}{failed_requests}{RESET} this session {GRAY}> Req delay: {current_req_delay}s')
		print(f'  {GRAY}*{RESET} {DARK_RED}Latest Error:{RESET} {latest_error}')
		print(equal_bar_end)
		
		if UPLOAD_DELAY > 19 and recently_saved or current_time - last_upload_time < 1:
			print(f'{" " * int(len(equal_bar_start)/2 - 8)}{GRAY}[ {GREEN}Saved ! {GRAY}]')
			recently_saved = False
	
	
def print_finished_message(START_TIME):
	
	equal_bar_count = '='*34 if MODE == 0 else '='*22
	equal_bar_end = f'\n{GRAY}{equal_bar_count}[ {timedelta(seconds=round(monotonic() - START_TIME))} ]{equal_bar_count}\n'
	equal_bar_start = '=' * (len(equal_bar_end)-7)

	system('cls')
	print(f'{GRAY}{equal_bar_start}\n')
	print(f'  {GREEN}Successfully scanned all {UNDERLINE}{YELLOW}{MAX_GAMES}{RESET} {GREEN}{target_name}!{RESET}')
	print(f"\n  Set {YELLOW}'{local_last_id_name}'{RESET} in {YELLOW}'saved_last_ids.py'{RESET} \n  to your desired starting point to rescan.")

	if MODE == 0:
		print(f'  \n  {GRAY}* Note:{RESET} This number is only an estimate of how many Roblox games exist.')
		print('  As more games get added it must be updated accordingly.')
		print(f"  You can do so by increasing {YELLOW}'MAX_GAMES'{RESET} in {YELLOW}'get_game_data.py'{RESET}.\n")
	print(equal_bar_end)
	
	
def save_data(current_id):

	con.commit()
	
	default = [f'last_find_uid = {last_find_uid}\n', 
	           f'last_update_db_id = {last_update_db_id}\n', 
	           f'last_votes_db_id = {last_votes_db_id}\n', 
	           f'last_badge_db_id = {last_badge_db_id}']	  
	
	updated = (f'last_find_uid = {current_id}\n', 
			   f'last_update_db_id = {current_id}\n', 
	           f'last_votes_db_id = {current_id}\n', 
	           f'last_badge_db_id = {current_id}')
			   
	default[MODE] = updated[MODE]
	
	save = open('saved_last_ids.py', 'w')
	save.write(''.join(str(line) for line in default))
	save.close()
	
	
def parse_game_data(games, uids) -> None:
	
	global filtered_ids
	parsed_data = []
	
	for i in range(len(uids)):
		
		game = games[i]
		
		uid = uids[i]
		place_id = game['rootPlaceId']
		
		name = game['name']
		desc = game['description']
		genre = game['genre']
		
		created = game['created']
		updated = game['updated']
		visits = game['visits']
		
		players = game['playing']
		max_players = game['maxPlayers']
		creator = game['creator']['name']
		
		favorites = game['favoritedCount']
		
		if MODE == 0:
			if favorites < MIN_FAVORITES or visits < MIN_VISITS or name == '[ Content Deleted ]' or created == updated:
				continue
			
			if (desc == DEFAULT_DESC1 or desc == DEFAULT_DESC2 or desc == '') and name == f"{creator}'s Place":
				continue
			
			if desc == '':
				desc = None  
			
			filtered_ids += 1
			
		parsed_data.append((place_id, name, players, desc, created, updated, max_players, creator, genre, visits, uid))
		
	if MODE == 0:
		con.executemany('''
			INSERT OR IGNORE INTO games (
				place_id, 
				name,
				players,
				desc,
				created,
				updated,
				max_players,
				creator,
				genre,
				visits,
				uid
			) 
			VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', parsed_data)
		
	else:
		con.executemany('''
			UPDATE games SET 
				place_id = ?, 
				name = ?,
				players = ?,
				desc = ?, 
				created = ?, 
				updated = ?, 
				max_players = ?, 
				creator = ?, 
				genre = ?,
				visits = ?
				WHERE uid = ?''', parsed_data)
					
					
def parse_votes(games, uids) -> None:
	
	global filtered_ids
	
	parsed_data = []
	delete_these_uids = []

	for game in games:
					
		uid = game['id']
		likes = game['upVotes']
		dislikes = game['downVotes']
		popularity = likes + dislikes
		ratio = 0.0
		
		if popularity != 0:
			ratio = likes/popularity
			ratio = round(ratio, 5)
		
		if FILTER_VOTES:
			if popularity >= MIN_POPULARITY and ratio > MIN_RATIO:
				
				filtered_ids += 1
				parsed_data.append((ratio, popularity, uid))
				
			else:
				delete_these_uids.append((uid,))
				
		else:
			parsed_data.append((ratio, popularity, uid))
	
	if len(delete_these_uids) != 0:
		con.executemany('DELETE FROM games WHERE uid = ?', delete_these_uids)
	
	con.executemany('UPDATE games SET ratio = ?, popularity = ? WHERE uid = ?', parsed_data)
	

def parse_badges(game, uid) -> None:

	global filtered_ids
	
	badge_count = 0
			
	cur.execute('SELECT visits FROM games WHERE uid = ?', (uid[0],))
	visits = cur.fetchall()[0][0]
	
	rarities = []
	rarest_badge = None
	
	for badge in game:
		
		if badge['enabled'] == False:
			continue
		
		awarded = badge['statistics']['awardedCount']
		
		if awarded < 2:
			continue
	
		badge_count += 1
		filtered_ids += 1
		
		rarity = awarded/visits*100
		rarity = round(rarity, 10)
		rarities.append(rarity)
	
	if visits != None and badge_count != 0:
		rarities.sort()
		rarest_badge = rarities[0]
	
	parsed_data = (badge_count, rarest_badge, uid[0])
	con.execute('UPDATE games SET badge_count = ?, rarest_badge = ? WHERE uid = ?', parsed_data)


PARSING_MODES = (parse_game_data, parse_game_data, parse_votes, parse_badges)


async def fetch_request(session, uid_batch, batch_end, previous_cursor):

	global active_requests, consecutive_success_requests, current_req_delay, latest_finished_batch, resettable_scanned_uids, failed_requests, latest_error
	url = None
	
	if MODE != 3:
		string_uids = ','.join(str(uid) for uid in uid_batch)
		url = f'{target_url}{string_uids}'
		
	else:
		if previous_cursor == None:
			url = f'https://badges.roblox.com/v1/universes/{uid_batch[0]}/badges?limit=100'
		else:
			url = f'https://badges.roblox.com/v1/universes/{uid_batch[0]}/badges?limit=100&cursor={previous_cursor}'
	
	active_requests += 1

	while True: 
		try:
			async with session.get(url) as response:
				
				if response.status == 200:
				
					raw = await response.json()
					data = raw['data']
					
					if MODE != 3 and len(data) != len(uid_batch) or MODE == 3 and raw['nextPageCursor'] and len(data) != 100:
						
						if len(raw['data']) != 0:
							latest_error = f'{YELLOW}Failed to retrieve game data, retrying...'
						else:
							latest_error = f"{DARK_RED}Received no game data, retrying... {GRAY}Is {YELLOW}'MAX_GAMES' {GRAY}in {YELLOW}'get_game_data.py' {GRAY}set too high?"
						continue
						
					if MODE == 3:
						if raw['nextPageCursor']:

							next_data = await fetch_badges(session, uid_batch, raw['nextPageCursor'])
							data.extend(*[next_data])
							
							if previous_cursor:
								return data
							
					try:
						PARSING_MODES[MODE](data, uid_batch)
					
					except:
						consecutive_success_requests = 0
						current_req_delay = RATE_LIMIT_DELAY
						failed_requests += 1
					
						latest_error = f'{DARK_RED}Rate Limited, retrying...{RESET} {GRAY}| {DARK_RED}Error {RED}{response.status}'
						await asyncio.sleep(REQUEST_RETRY_DELAY + round(random(), 3))
						continue
					
					if batch_end > latest_finished_batch:
						latest_finished_batch = batch_end
					
					consecutive_success_requests += 1
					resettable_scanned_uids += len(uid_batch)
					
					active_requests -= 1
					break
					
				else:
					consecutive_success_requests = 0
					current_req_delay = RATE_LIMIT_DELAY
					failed_requests += 1
					
					latest_error = f'{DARK_RED}Rate Limited, retrying...{RESET} {GRAY}| {DARK_RED}Error {RED}{response.status}'
					await asyncio.sleep(REQUEST_RETRY_DELAY + round(random(), 3))
				
		except Exception as e:
			latest_error = f'{RED}Error{DARK_RED}, retrying... {GRAY}| {DARK_RED}{e}'


async def main():
	
	global last_avg_reset_time, resettable_scanned_uids, last_upload_time, recently_saved, current_req_delay
	
	uids = []
	
	# For updating games: Gets available uids from database to scan
	if MODE != 0:
		cur.execute('SELECT uid FROM games LIMIT ? OFFSET ?', (MAX_GAMES, local_last_id))
		tuple_uids = cur.fetchall()
		
		for tup in tuple_uids:
			uids.append(tup[0])
			
		tuple(uids)
	
	async with ClientSession(connector=TCPConnector(limit=0, limit_per_host=0, force_close=True)) as session:
		
		START_TIME = monotonic()
		
		stats = asyncio.create_task(print_stats(START_TIME))
		
		for batch_start in range(0, SCANNABLE_GAMES, BATCH_SIZE):
			current_time = monotonic()
				
			if current_time - last_avg_reset_time >= 60:
				resettable_scanned_uids = 0
				last_avg_reset_time = current_time
				
			if current_time - last_upload_time >= UPLOAD_DELAY:
				save_data(local_last_id + latest_finished_batch)
				last_upload_time = current_time
				recently_saved = True
			
			if MODE == 0:
				uid_batch = range(local_last_id+batch_start, min(local_last_id+batch_start+BATCH_SIZE, MAX_GAMES))
			else:
				uid_batch = uids[batch_start:batch_start+BATCH_SIZE]
			
			while active_requests >= MAX_CONCURRENT_REQUESTS:
				await asyncio.sleep(0)
				
			asyncio.create_task(fetch_request(session, uid_batch, batch_start+BATCH_SIZE, None))
			
			if consecutive_success_requests >= RATE_LIMIT_THRESHOLD:
				current_req_delay = REQUESTS_DELAY
			
			await asyncio.sleep(current_req_delay)
		
		while active_requests != 0:
			await asyncio.sleep(0)
			
		save_data(MAX_GAMES)
		stats.cancel()
		
		print_finished_message(START_TIME)
			

asyncio.run(main())
con.close()
exit()